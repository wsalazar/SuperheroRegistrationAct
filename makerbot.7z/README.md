# Superhero Registration Act

I created a registration and login page just for fun. I decided to not use any libraries except for the ones I created using vanilla javascript. I also minified my css an js. Quite frankly, I didn't really have to minify them since they load pretty fast. They're not huge files. But I said what the hell, why not. It costs me nothing to do so.

Note: this was for a recent design exercise I had with a company.

##### Technologies used
- SQLite3
- PHP5.6
- Vanilla JS
- HTML5/CSS3